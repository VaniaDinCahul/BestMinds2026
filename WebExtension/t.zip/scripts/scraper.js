function extractPageText() {
    if (!document.body) return "";

    return document.body.innerText || document.body.textContent || "";
}
